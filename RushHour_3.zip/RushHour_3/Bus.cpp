#include <conio.h>
#include <iostream>
#include "Consola.h"
#include "Bus.h"

#include "keycode.h"
using namespace std;
const int CHARACTER_WIDTH = 5;
const int CHARACTER_HEIGHT = 12;



Bus::Bus(int X, int Y, int color) {
    posx = X;
    posy = Y;
    this->color = color;
}
void Bus::clearCharacter(int x, int y) {
    for (int i = 0; i < CHARACTER_HEIGHT; i++) {
        for (int j = -1; j < CHARACTER_WIDTH + 1; j++) {
            xyputstr(x + j, y + i, "  ");
        }
    }
}

void Bus::drawCharacter(int x, int y) {
    for (int i = 0; i < CHARACTER_HEIGHT; i++) {
        for (int j = -1; j < CHARACTER_WIDTH + 1; j++) {
            textcolor(this->color);
            xyputstr(x + j, y + i, "��");
        }
    }
}



void Bus::Move(int key) {
    int oldx = posx;
    int oldy = posy;

    clearCharacter(oldx, oldy);

    switch (key) {
    case M_UPKEY:
        if (posy > 4) posy -= 4; break;
    case M_DOWNKEY:
        if (posy < 12) posy += 4; break;
    }

    drawCharacter(posx, posy);
}



