#include <conio.h>
#include <iostream>
#include "Consola.h"
#include "Car.h"

#include "keycode.h"
using namespace std;

Car::Car(int X, int Y, int color) {
    posx = X;
    posy = Y;
   this-> color = color;
}
void Car::clearCharacter(int x, int y) {
    for (int i = 0; i < CAR_HEIGHT; i++) {
        for (int j = -1; j < CAR_WIDTH +1; j++) {
            xyputstr(x + j, y + i, "  ");
        }
    }
}

void Car::drawCharacter(int x, int y) {
    for (int i = 0; i < CAR_HEIGHT; i++) {
        for (int j = -1; j < CAR_WIDTH +1; j++) {
            textcolor(this->color);
            xyputstr(x + j, y + i, "��");
        }
    }
}



void Car::Move(int key) {
    int oldx = posx;
    int oldy = posy;

    clearCharacter(oldx, oldy);

    switch (key) {
    case M_UPKEY:
        if (posy > 4) posy -= 4; break;
    case M_DOWNKEY:
        if (posy < 16) posy += 4; break;
    }
        int where(posx);
    int wherey(posy);
    drawCharacter(posx, posy);
}

