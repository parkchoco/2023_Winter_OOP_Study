#pragma once
using namespace std;
#define TABLE_X 26 //��Ʈ���� �� x �� ����
#define TABLE_Y 26 //��Ʈ���� �� y �� ����
#ifndef CAR_H
#define CAR_H



class Car {
private:
    const int CAR_WIDTH = 5;  // Car�� �ʺ�
    const int CAR_HEIGHT = 8;
    int color;
    int table[TABLE_Y][TABLE_X];
public:
    int posx, posy;
    Car(int X, int Y, int color);
    void clearCharacter(int x, int y);
    void drawCharacter(int x, int y);
    void Move(int key);



    int getkey() {
        int ch = _getch();
        if (ch != 0xe0)
            return ch;
        else {
            int ch2 = _getch();
            return (0xe000 | ch2);
        }
    }
    void xyputstr(int x, int y, const char* str) {
        gotoxy(x, y);
        cout << str;
    }
};
#endif CAR_H