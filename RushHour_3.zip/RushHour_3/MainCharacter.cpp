
#include <conio.h>
#include <iostream>
#include "Consola.h"
#include "MainCharacter.h"

#include "keycode.h"
using namespace std;
const int CHARACTER_WIDTH = 8;
const int CHARACTER_HEIGHT = 4;



MainCharacter::MainCharacter(int X, int Y, int color) {
    posx = X;
    posy = Y;
    this->color = color;
}

void MainCharacter::clearCharacter(int x, int y) {
    for (int i = 0; i < CHARACTER_HEIGHT; i++) {
        for (int j = 0; j < CHARACTER_WIDTH; j++) {
            xyputstr(x + j * 2, y + i, "  ");
        }
    }
}

void MainCharacter::drawCharacter(int x, int y) {
    for (int i = 0; i < CHARACTER_HEIGHT; i++) {
        for (int j = 0; j < CHARACTER_WIDTH; j++) {

            textcolor(BLUE);
            xyputstr(x + j * 2, y + i, "��");

        }
    }
}


/*������ �׸��� �Լ�*/


void MainCharacter::Move(int key) {
    int oldx = posx;
    int oldy = posy;

    clearCharacter(oldx, oldy);

    switch (key) {
    case M_LEFTKEY:
        if (posx > 4) posx -= 8; break;
    case M_RIGHTKEY:
        if (posx < 48) posx += 8; break;
    }

    drawCharacter(posx, posy);

}

