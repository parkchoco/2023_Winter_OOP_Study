#include "isCollision.h"
#include "Car.h"
#include "MainCharacter.h"

bool isCollision(MainCharacter& character, Car& car) {
    // MainCharacter�� ��ġ�� ũ�⸦ �����ɴϴ�.
    int charX = character.getPosX();
    int charY = character.getPosY();
    int charWidth = CHARACTER_WIDTH;
    int charHeight = CHARACTER_HEIGHT;

    // Car�� ��ġ�� ũ�⸦ �����ɴϴ�.
    int carX = car.getPosX();
    int carY = car.getPosY();
    int carWidth = CHARACTER_WIDTH;
    int carHeight = CHARACTER_HEIGHT;

    // �浹 Ȯ�� �����Դϴ�.
    if (charX < carX + carWidth &&
        charX + charWidth > carX &&
        charY < carY + carHeight &&
        charHeight + charY > carY) {
        return true;
    }
    return false;
}