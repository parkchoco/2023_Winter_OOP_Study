#pragma once
#include "Consola.h"
#include <iostream>

using namespace std;
void xyputstr(int x, int y, const char* str) {
    gotoxy(x, y);
    cout << str;
}